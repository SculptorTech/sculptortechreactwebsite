import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section
      id="home"
      className="
        relative pt-16 pb-8 overflow-hidden
        bg-white dark:bg-slate-600
        transition-colors
      "
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
        src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1600"
        alt="Modern Office"
          className="
            w-full h-full object-cover
            opacity-90 dark:opacity-30
            "
        />

        {/* LEFT-SIDE OVERLAY (Light: darker, Dark: unchanged) */}
        <div
          className="
            absolute inset-0
            bg-gradient-to-r
            from-white/60 via-white/40 to-transparent
            dark:from-black/70 dark:via-black/50 dark:to-black/30
          "
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-[90vh] flex flex-col justify-center">

        <div className="max-w-3xl">
          <h1
            className="
              text-5xl md:text-6xl font-bold mb-6 leading-tight
              text-black-900 dark:text-white
            "
          >
            Sculpting Your{' '}
            <span className="text-teal-600 dark:text--200">
              Digital Future
            </span>
          </h1>

          <p
            className="
              text-xl mb-8 leading-relaxed
              text-slate-900 dark:text-gray-500
            "
          >
            We transform complex business challenges into elegant digital
            solutions. From web development to business analytics, we build the
            infrastructure for your success.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#contact"
              className="
                px-4 py-1 rounded-lg font-bold text-lg
                bg-teal-600 hover:bg-teal-300
                text-white transition-all
                flex items-center justify-center
              "
            >
              Get Started
              <ArrowRight className="ml-2" size={15} />
            </a>

            <a
              href="#services"
              className="
                px-4 py-1 rounded-lg font-bold text-lg text-center
                bg-slate-100 hover:bg-slate-200
                text-slate-900 border border-slate-200
                dark:bg-slate-800 dark:hover:bg-slate-700
                dark:text-white dark:border-slate-700
                transition-all
              "
            >
              View Services
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
