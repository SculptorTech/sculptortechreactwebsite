import React from 'react';
import {
  Mail,
  MapPin,
  Users,
  Briefcase,
  Building2,
  Globe,
  CheckCircle2,
} from 'lucide-react';

const About = () => {
  const specialities = [
    'Web Design & Development',
    'Mobile App Development',
    'Social Media Marketing',
    'SEO Optimization',
    'Web Analytics',
  ];

  return (
    <section
      id="about"
      className="
        py-6 relative overflow-hidden
        bg-white dark:bg-slate-950
        transition-colors
      "
    >
      {/* Background decoration */}
      <div
        className="
          absolute top-0 right-0 w-1/3 h-full
          bg-slate-100 dark:bg-slate-900
          skew-x-12 translate-x-20
          opacity-50 dark:opacity-40
          z-0
        "
      />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* LEFT SIDE */}
          <div>
            <div
              className="
                inline-block px-4 py-2 mb-6 rounded-full text-sm font-bold
                bg-purple-100 text-purple-700
                dark:bg-purple-900 dark:text-purple-300
              "
            >
              Who We Are
            </div>

            <h2
              className="
                text-4xl md:text-5xl font-bold mb-6 leading-tight
                text-slate-900 dark:text-white
              "
            >
              Empowering SMEs with{' '}
              <span className="text-purple-600 dark:text-purple-400">
                Smart Tech
              </span>{' '}
              Solutions.
            </h2>

            <p
              className="
                text-lg mb-8 leading-relaxed
                text-slate-700 dark:text-slate-400
              "
            >
              SculptorTech Pvt Ltd helps Small and Medium Enterprises achieve
              their revenue goals by providing cutting-edge technology and
              business solutions. We don&apos;t just build software; we build
              the engine for your growth.
            </p>

            {/* Specialities */}
            <div className="mb-10">
              <h3
                className="
                  text-sm font-bold uppercase tracking-wider mb-4
                  text-slate-400 dark:text-slate-500
                "
              >
                Our Specialities
              </h3>

              <div className="flex flex-wrap gap-3">
                {specialities.map((item, index) => (
                  <span
                    key={index}
                    className="
                      flex items-center px-4 py-2 rounded-lg text-sm font-medium
                      bg-white border border-slate-200 text-slate-700
                      shadow-sm
                      hover:border-purple-300
                      dark:bg-slate-900 dark:border-slate-700 dark:text-slate-300
                      transition-colors
                    "
                  >
                    <CheckCircle2
                      size={16}
                      className="text-purple-500 mr-2"
                    />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Info Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Item 1 */}
              <div className="flex items-start">
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg mr-4 text-blue-600 dark:text-blue-400">
                  <Briefcase size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Industry
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    IT Services & Consulting
                  </p>
                </div>
              </div>

              {/* Item 2 */}
              <div className="flex items-start">
                <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg mr-4 text-green-600 dark:text-green-400">
                  <Users size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Company Size
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    05–20 Employees
                  </p>
                </div>
              </div>

              {/* Item 3 */}
              <div className="flex items-start">
                <div className="p-3 bg-orange-100 dark:bg-orange-900 rounded-lg mr-4 text-orange-600 dark:text-orange-400">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Headquarters
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Pune, Maharashtra
                  </p>
                </div>
              </div>

              {/* Item 4 */}
              <div className="flex items-start">
                <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg mr-4 text-purple-600 dark:text-purple-400">
                  <Building2 size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Type
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Private Limited
                  </p>
                </div>
              </div>

              {/* Item 5 */}
              <div className="flex items-start">
                <div className="p-3 bg-red-100 dark:bg-red-900 rounded-lg mr-4 text-red-600 dark:text-red-400">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Email
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400 break-all">
                    sculptortechpvtltd@gmail.com
                  </p>
                </div>
              </div>

              {/* Item 6 */}
              <div className="flex items-start">
                <div className="p-3 bg-teal-100 dark:bg-teal-900 rounded-lg mr-4 text-teal-600 dark:text-teal-400">
                  <Globe size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white">
                    Freelance
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Available for Hire
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT SIDE IMAGE */}
          <div className="relative h-full">
            <div
              className="
                rounded-2xl overflow-hidden shadow-2xl
                border-8 border-white dark:border-slate-900
                h-full
              "
            >
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800"
                alt="Team Collaboration"
                className="w-full h-full object-cover min-h-[500px]"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
