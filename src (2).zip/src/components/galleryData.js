import gallery1 from "src/components/assets/gallery.jpg";
import gallery2 from "src/components/assets/gallery2.jpg";
import gallery3 from "src/components/assets/gallery3.jpg";
import gallery2 from "src/components/assets/gallery4.jpg";


export const galleryImages = [
  {
    id: 1,
    img: gallery1,
    title: "Cyber Security",
    height: 700, // Tall image
    url: "#"
  },
  {
    id: 2,
    img: gallery2,
    title: "Tech Team",
    height: 400, // Short image
    url: "#"
  },
  {
    id: 3,
    img: gallery3,
    title: "Data Analytics",
    height: 700,
    url: "#"
  },
  {
    id: 4,
    img: gallery4,
    title: "Code Matrix",
    height: 400, 
    url: "#"
  },
  {
    id: 5,
    img: "https://images.unsplash.com/photo-1504384308090-c54be3855833?auto=format&fit=crop&q=80&w=800",
    title: "Server Room",
    height: 750,
    url: "#"
  },
  {
    id: 6,
    img: "C:\Sculptortech_website\src\assets\WhatsApp Image 2026-02-18 at 10.29.39 AM.jpeg",
    title: "AI Development",
    height: 750,
    url: "#"
  },
  {
    id: 7,
    img: "https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&q=80&w=800",
    title: "Innovation",
    height: 450,
    url: "#"
  },
  {
    id: 8,
    img: "https://images.unsplash.com/photo-1558494949-ef2bb3cc6c5b?auto=format&fit=crop&q=80&w=800",
    title: "Cloud Services",
    height: 450,
    url: "#"
  }
];